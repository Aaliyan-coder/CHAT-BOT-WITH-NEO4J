% Facts for ali@gmail.com
father(ahmed,ali).
